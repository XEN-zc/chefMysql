# aws-sdk Cookbook CHANGELOG

This file is used to list changes made in each version of the aws-sdk cookbook.

## v1.42.0 (2014-04-03)
- Add dependency on apt cookbook
- Add dependency on build-essential cookbook
- Add integration tests
- Add support for Ubuntu 14.04
- Update aws-sdk chef_gem resource to 1.42.0
- Update unf chef_gem resource to install version 0.1.4
- Update chef-spec to 4.0.0

## v1.38.0 (2014-03-30)
- Initial release with development and CI toolchain configured
